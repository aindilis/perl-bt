# perl-bt
Pure Perl Behavior Tree Implementation

Does nothing at present.  Release early release often.

Hopefully will have an at least minimally functioning real-time pure Perl Behavior Tree library.  Please assist if possible.
