package FRDCSA::BehaviorTree::ExecutionMonitor;

use Data::Dumper;

use Class::MethodMaker
  new_with_init => 'new',
  get_set       =>
  [

   qw / BehaviorTree /

  ];

sub init {
  my ($self,%args) = @_;
}

sub Start {
  my ($self,%args) = @_;

}

sub Stop {
  my ($self,%args) = @_;

}

1;


