#!/bin/sh

git add .
git commit .
git pull
git push
