package FRDCSA::BehaviorTree::Parser;

use Data::Dumper;

use Class::MethodMaker
  new_with_init => 'new',
  get_set       =>
  [

   qw / Source /

  ];

sub init {
  my ($self,%args) = @_;
}


sub LoadSource {
  my ($self,%args) = @_;

}

sub Parse {
  my ($self,%args) = @_;

}

1;


